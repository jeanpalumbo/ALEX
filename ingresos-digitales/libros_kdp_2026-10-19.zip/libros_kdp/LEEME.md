# Libros KDP listos para subir (19 oct 2026)

Tres productos terminados para Amazon KDP (tapa blanda, 8,5 × 11 in, tinta negra, papel blanco, sin sangrado).
Cada carpeta tiene el interior, la portada completa y `listing.md` con todo lo que hay que copiar en KDP
(título, subtítulo, descripción, 7 palabras clave, categorías, precio, declaración de IA y checklist).

| Carpeta | Producto | Páginas | Precio sugerido | Prioridad |
|---|---|---|---|---|
| `agenda2027/` | Agenda 2027 para mayores: semana a la vista + 53 sopas de letras, festivos según BOE | 130 | 9,99 € | 1ª (se vende de nov. a enero) |
| `vol1/` | Sopa de letras para mayores Vol. 1 "Recuerdos de España" (100 sopas) | 134 | 9,99 € | 2ª |
| `vol2/` | Sopa de letras para mayores Vol. 2 "Recuerdos de los años 60" (100 sopas) | 134 | 9,99 € | 3ª |

## Estado
- Cuenta KDP: información fiscal validada (retención 0 %), cuenta bancaria en verificación.
- Pendiente: respuesta del servicio de atención al cliente de Amazon antes de subir.
- Subir uno al día, desde ordenador, siguiendo `SUBIR_A_KDP.md`.
- Declaración de IA: texto SÍ (escrito con Claude y revisado), imágenes NO, traducción NO.
- Autor puesto: "Piero Palumbo" (se puede cambiar; requiere regenerar los PDF).

## Origen y regeneración
Código en github.com/jeanpalumbo/ALEX, rama `claude/new-session-akjsxp`, carpeta `ingresos-digitales/`:
- `python -m plan_c_kdp.build` → vol1 y vol2
- `python -m plan_c_kdp.agenda` → agenda2027
Los temas y palabras están en `plan_c_kdp/themes/*.yaml` y `plan_c_kdp/agenda/agenda_2027.yaml`.
