# Ficha KDP — Agenda 2027 para mayores en letra grande (Vol. 2027)

> Generado por `python -m plan_c_kdp.build`. Revisar y copiar a mano en kdp.amazon.com.

## 1. Detalles del libro

| Campo | Valor |
|---|---|
| Idioma | Español |
| Título | Agenda 2027 para mayores en letra grande |
| Subtítulo | Semana a la vista con 53 sopas de letras, festivos y refranes. Un regalo para padres y abuelos |
| Serie | (sin serie) |
| Autor | Piero Palumbo |
| Contenido para adultos | No |

### Descripción (pegar en el editor de KDP; admite estas etiquetas HTML)

```html
<p><b>Una agenda pensada para que nuestros mayores lo tengan todo a mano, en letra bien grande.</b></p>
<p>Semana a la vista de enero a diciembre de 2027, con días grandes y espacio de sobra para apuntar citas médicas, cumpleaños y recados. Junto a cada semana, una sopa de letras con un tema de esa época del año: los Reyes Magos, el Carnaval, la Semana Santa, San Juan, la vendimia, las castañas, la lotería de Navidad...</p>
<ul>
<li>Semana a la vista en letra grande (de lunes a domingo).</li>
<li>53 sopas de letras de temporada, con soluciones al final.</li>
<li>Festivos nacionales de 2027 marcados en cada semana.</li>
<li>Un refrán tradicional para cada semana.</li>
<li>Páginas para datos personales y médicos, teléfonos importantes y cumpleaños.</li>
<li>Formato grande: 21,6 × 27,9 cm, en papel blanco.</li>
</ul>
<p>El regalo ideal para Navidad: útil todo el año y entretenido cada semana.</p>
```

### 7 palabras clave

1. agenda 2027 letra grande
2. calendario 2027 para personas mayores
3. agenda semanal 2027 para mayores
4. regalo para abuelos y abuelas
5. sopa de letras letra grande para mayores
6. planificador 2027 semana vista letra grande
7. agenda con pasatiempos y refranes

### Categorías sugeridas (confirmar en el selector de KDP, los nombres cambian)

- Juegos y actividades > Sopas de letras (Games & Activities > Word Search)
- Juegos y actividades > Rompecabezas (Games & Activities > Puzzles)
- Salud, familia y desarrollo personal > Envejecimiento (Health > Aging)

## 2. Contenido

| Campo | Valor |
|---|---|
| ISBN | Usar el ISBN gratuito de KDP |
| Tinta y papel | Negro y blanco (papel blanco) |
| Tamaño | 8.5 × 11 in (21,59 × 27,94 cm) |
| Sangrado | Sin sangrado (interior) |
| Acabado de cubierta | Brillo (recomendado para colores vivos) |
| Interior | `agenda2027_interior.pdf` — 130 páginas |
| Cubierta | `agenda2027_cover.pdf` — 17.543 × 11.250 in (con sangrado) |

### Declaración de IA (obligatoria)

- **Texto: SÍ, generado con IA.** Los temas, las palabras y las introducciones los redactó
  Claude; Piero los revisó y editó. Las cuadrículas las genera un programa (no es IA generativa),
  pero el texto del libro sí lo es.
- **Imágenes: NO** si se usa la portada tipográfica tal cual. **SÍ** si se añade una
  ilustración hecha con ChatGPT u otra herramienta de IA.
- **Traducción: NO.**

## 3. Precio

| Mercado | Coste de impresión | Precio sugerido | Regalía estimada |
|---|---|---|---|
| Amazon.es (EUR) | 2.83 € | 9.99 € | 3.16 € |
| Amazon.com (USD) | $3.21 | $9.99 | $2.78 |

- En euros, 9,99 € es el umbral del 60 % de regalía (a 9,98 € o menos baja al 50 %).
  Confirmar en la calculadora de KDP antes de publicar.
- Antes de fijar el precio, mirar el precio de 3-4 títulos del ranking medido
  (sección 11 del plan). No hay datos de precios de la competencia en este informe.
- Distribución ampliada: no activar al principio (paga 40 % antes del coste de impresión).

## 4. Checklist antes de enviar a revisión

- [ ] Abrí el PDF interior y leí al menos 10 sopas (legibilidad, temas "de mayores españoles").
- [ ] Revisé las palabras e introducciones de los temas (archivo YAML del libro).
- [ ] Comprobé en el BOE la resolución con los festivos de 2027 (se publica cada otoño) y coinciden con la página de festivos.
- [ ] Publicarla cuanto antes: la agenda se vende sobre todo de noviembre a enero.
- [ ] El nombre de autor es el que quiero usar (real o seudónimo).
- [ ] Vista previa de KDP sin errores de márgenes ni de texto fuera de zona.
- [ ] Declaración de IA marcada (texto: sí).
- [ ] Pedí una copia de prueba (opcional, recomendado antes de la campaña de Navidad).

## Temas del volumen

1. Nochevieja y Año Nuevo
2. Los Reyes Magos
3. San Antón y los animales
4. Las rebajas de enero
5. Días de frío
6. Febrerillo loco
7. Carnaval
8. Amor y enamorados
9. Almendros en flor
10. Las aves que vuelven
11. La huerta en primavera
12. San José y el Día del Padre
13. Semana Santa
14. Pascua
15. Primavera en flor
16. Feria de abril
17. Libros y lectura
18. Día de la Madre
19. Mayo florido
20. San Isidro
21. Romerías
22. Primeras comuniones
23. Fin de curso
24. Llega el calor
25. Fruta de verano
26. Noche de San Juan
27. Vacaciones de verano
28. San Fermín
29. Un día de playa
30. Santiago y el Camino
31. Día de los Abuelos
32. Noches de verano
33. Fiestas de agosto
34. Fiestas del pueblo
35. Helados y refrescos
36. Vuelta al cole
37. Uvas y vendimia
38. Setas y bosque
39. Llega el otoño
40. Membrillo y conservas
41. Animales de compañía
42. Fiesta del Pilar
43. Castañas asadas
44. Relojes y horas
45. Todos los Santos
46. Guisos de cuchara
47. Días de lluvia
48. Música y bandas
49. Preparando la Navidad
50. El puente de diciembre
51. La lotería de Navidad
52. Nochebuena y Navidad
53. Despedimos el año
